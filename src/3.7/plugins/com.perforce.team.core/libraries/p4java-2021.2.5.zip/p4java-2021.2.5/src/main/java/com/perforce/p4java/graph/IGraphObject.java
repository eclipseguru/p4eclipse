package com.perforce.p4java.graph;

public interface IGraphObject {

	String getSha();

	String getType();
}

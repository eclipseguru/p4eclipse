package com.perforce.p4java.graph;


public interface IGraphListTree {

	int getMode();

	String getType();

	String getSha();

	String getName();
}

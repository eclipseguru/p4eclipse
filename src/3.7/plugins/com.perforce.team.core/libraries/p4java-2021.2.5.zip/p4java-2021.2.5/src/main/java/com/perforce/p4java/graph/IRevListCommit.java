package com.perforce.p4java.graph;


public interface IRevListCommit {

    String getCommit();
}

package com.perforce.p4java.graph;

public interface IGraphRef {

	String getRepo();

	String getType();

	String getSha();

	String getName();
}

package com.perforce.p4java.mapapi;

public class MapParam {
    public int	start;		// offsets into Joiner::StrBuf::Text()
    public int	end;
}
